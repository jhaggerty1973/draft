def get_news_articles(ticker):
    # TODO: Use NewsAPI or RSS parsing to pull headlines
    return f"Simulated news for {ticker}"