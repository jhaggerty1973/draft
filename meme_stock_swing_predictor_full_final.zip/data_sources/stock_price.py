def get_live_price(ticker):
    # TODO: Replace with yfinance or polygon API
    import random
    return round(random.uniform(1, 200), 2)